export class Profile {
  constructor(public profileName: string, public cities: string[]) {}
}